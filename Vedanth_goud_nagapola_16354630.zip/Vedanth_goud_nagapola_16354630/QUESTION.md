Q1. Based on the following table, design the three stages of reproducible workflow, includes the work you can do and the folder structure in each stage (reference study case in chapter 3). (5 points)

Q2. Perform 5 data visualization tasks on the student performance dataset given in the link below (create 5 different visualizations). Explain what kind analysis has become easier with each of the visualizations. Create the folder structure for this question similar to question 1. (15 points).

Data link: https://app.box.com/s/ji910ez3ycw137rw07xnhielxey7ww41

Workflow: [Workflow.docx](https://github.com/Thanay1004/PDS/files/12734322/Workflow.docx)



